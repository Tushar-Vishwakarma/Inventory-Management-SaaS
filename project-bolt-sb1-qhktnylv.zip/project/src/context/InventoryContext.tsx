import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Product, SaleRecord } from '../types/inventory';
import * as sheetsService from '../services/sheetsService';

interface InventoryContextType {
  products: Product[];
  loading: boolean;
  error: string | null;
  fetchProducts: () => Promise<void>;
  updateProduct: (product: Product) => Promise<void>;
  deleteProduct: (id: string) => Promise<void>;
  uploadSales: (csvData: string) => Promise<{ updatedCount: number }>;
}

const InventoryContext = createContext<InventoryContextType | undefined>(undefined);

export const useInventory = () => {
  const context = useContext(InventoryContext);
  if (context === undefined) {
    throw new Error('useInventory must be used within an InventoryProvider');
  }
  return context;
};

interface InventoryProviderProps {
  children: ReactNode;
}

export const InventoryProvider = ({ children }: InventoryProviderProps) => {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchProducts = async () => {
    setLoading(true);
    setError(null);
    
    try {
      const data = await sheetsService.getInventory();
      setProducts(data);
    } catch (err: any) {
      setError(err.message || 'Failed to fetch inventory data');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const updateProduct = async (product: Product) => {
    setLoading(true);
    setError(null);
    
    try {
      await sheetsService.updateInventoryItem(product);
      setProducts(prevProducts => 
        prevProducts.map(p => p.id === product.id ? product : p)
      );
    } catch (err: any) {
      setError(err.message || 'Failed to update product');
      console.error(err);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const deleteProduct = async (id: string) => {
    setLoading(true);
    setError(null);
    
    try {
      await sheetsService.deleteInventoryItem(id);
      setProducts(prevProducts => prevProducts.filter(p => p.id !== id));
    } catch (err: any) {
      setError(err.message || 'Failed to delete product');
      console.error(err);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const uploadSales = async (csvData: string) => {
    setLoading(true);
    setError(null);
    
    try {
      const result = await sheetsService.processSalesData(csvData);
      
      // Refresh products list after processing sales
      await fetchProducts();
      
      return result;
    } catch (err: any) {
      setError(err.message || 'Failed to process sales data');
      console.error(err);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProducts();
  }, []);

  const value = {
    products,
    loading,
    error,
    fetchProducts,
    updateProduct,
    deleteProduct,
    uploadSales
  };

  return <InventoryContext.Provider value={value}>{children}</InventoryContext.Provider>;
};