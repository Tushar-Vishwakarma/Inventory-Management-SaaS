import { useState } from 'react';
import { Upload, AlertTriangle, Check } from 'lucide-react';
import { useInventory } from '../../context/InventoryContext';
import { SaleRecord } from '../../types/inventory';
import toast from 'react-hot-toast';

const SalesUploadForm = () => {
  const { uploadSales } = useInventory();
  const [file, setFile] = useState<File | null>(null);
  const [previewData, setPreviewData] = useState<SaleRecord[]>([]);
  const [isUploading, setIsUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (!selectedFile) {
      return;
    }

    // Check file type (csv only)
    if (selectedFile.type !== 'text/csv' && !selectedFile.name.endsWith('.csv')) {
      setError('Please upload a CSV file only');
      setFile(null);
      return;
    }

    setFile(selectedFile);
    setError(null);
    setSuccess(false);
    
    // Parse CSV for preview
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const text = event.target?.result as string;
        const lines = text.split('\n');
        const headers = lines[0].split(',');
        
        // Check for required headers
        const requiredHeaders = ['date', 'sku', 'platform', 'quantity'];
        const missingHeaders = requiredHeaders.filter(
          (header) => !headers.map(h => h.trim().toLowerCase()).includes(header)
        );
        
        if (missingHeaders.length > 0) {
          setError(`Missing required headers: ${missingHeaders.join(', ')}`);
          return;
        }
        
        const data: SaleRecord[] = [];
        // Parse up to 5 rows for preview
        for (let i = 1; i < Math.min(lines.length, 6); i++) {
          if (lines[i].trim() === '') continue;
          
          const values = lines[i].split(',');
          const record: SaleRecord = {
            date: values[headers.indexOf('date')].trim(),
            sku: values[headers.indexOf('sku')].trim(),
            platform: values[headers.indexOf('platform')].trim().toLowerCase(),
            quantity: parseInt(values[headers.indexOf('quantity')].trim(), 10) || 0
          };
          
          data.push(record);
        }
        
        setPreviewData(data);
      } catch (error) {
        setError('Failed to parse CSV file. Please check the format.');
        console.error(error);
      }
    };
    
    reader.readAsText(selectedFile);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!file) {
      setError('Please select a file to upload');
      return;
    }
    
    setIsUploading(true);
    
    try {
      const reader = new FileReader();
      reader.onload = async (event) => {
        try {
          const text = event.target?.result as string;
          const result = await uploadSales(text);
          setSuccess(true);
          setFile(null);
          toast.success(`Successfully updated inventory with ${result.updatedCount} sales records`);
        } catch (error: any) {
          setError(error.message || 'Failed to process sales data');
          toast.error('Failed to process sales data');
        } finally {
          setIsUploading(false);
        }
      };
      
      reader.readAsText(file);
    } catch (error: any) {
      setError(error.message || 'Failed to read file');
      setIsUploading(false);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-sm overflow-hidden">
      <div className="px-6 py-5 border-b border-gray-200">
        <h3 className="text-lg font-medium text-gray-900">Upload Sales Data</h3>
        <p className="mt-1 text-sm text-gray-500">
          Upload your recent sales data to automatically adjust inventory levels
        </p>
      </div>
      
      <form onSubmit={handleSubmit} className="px-6 py-5">
        <div className="space-y-6">
          {!file ? (
            <div className="flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-md">
              <div className="space-y-1 text-center">
                <Upload className="mx-auto h-12 w-12 text-gray-400" />
                <div className="flex text-sm text-gray-600">
                  <label
                    htmlFor="file-upload"
                    className="relative cursor-pointer bg-white rounded-md font-medium text-indigo-600 hover:text-indigo-500 focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-indigo-500"
                  >
                    <span>Upload a CSV file</span>
                    <input
                      id="file-upload"
                      name="file-upload"
                      type="file"
                      className="sr-only"
                      accept=".csv"
                      onChange={handleFileChange}
                    />
                  </label>
                  <p className="pl-1">or drag and drop</p>
                </div>
                <p className="text-xs text-gray-500">CSV only (max 10MB)</p>
              </div>
            </div>
          ) : (
            <div>
              <div className="flex items-center justify-between p-4 border border-gray-200 rounded-md">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <div className="h-10 w-10 rounded-md bg-indigo-100 flex items-center justify-center">
                      <span className="text-indigo-600 text-xs font-medium">CSV</span>
                    </div>
                  </div>
                  <div className="ml-3">
                    <p className="text-sm font-medium text-gray-900">{file.name}</p>
                    <p className="text-xs text-gray-500">{(file.size / 1024).toFixed(2)} KB</p>
                  </div>
                </div>
                <button
                  type="button"
                  className="text-sm font-medium text-indigo-600 hover:text-indigo-500"
                  onClick={() => {
                    setFile(null);
                    setPreviewData([]);
                    setError(null);
                    setSuccess(false);
                  }}
                >
                  Change
                </button>
              </div>
              
              {/* Preview data */}
              {previewData.length > 0 && (
                <div className="mt-4">
                  <h4 className="text-sm font-medium text-gray-900 mb-2">Preview (first 5 rows):</h4>
                  <div className="bg-gray-50 rounded-md p-3 overflow-x-auto">
                    <table className="min-w-full divide-y divide-gray-200">
                      <thead>
                        <tr>
                          <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                          <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">SKU</th>
                          <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Platform</th>
                          <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Quantity</th>
                        </tr>
                      </thead>
                      <tbody>
                        {previewData.map((record, index) => (
                          <tr key={index} className={index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                            <td className="px-3 py-2 text-xs text-gray-500">{record.date}</td>
                            <td className="px-3 py-2 text-xs text-gray-500">{record.sku}</td>
                            <td className="px-3 py-2 text-xs text-gray-500">{record.platform}</td>
                            <td className="px-3 py-2 text-xs text-gray-500">{record.quantity}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </div>
          )}
          
          {error && (
            <div className="flex items-start p-4 rounded-md bg-red-50">
              <AlertTriangle className="h-5 w-5 text-red-400" />
              <div className="ml-3">
                <h3 className="text-sm font-medium text-red-800">Error</h3>
                <div className="mt-1 text-sm text-red-700">
                  <p>{error}</p>
                </div>
              </div>
            </div>
          )}
          
          {success && (
            <div className="flex items-center p-4 rounded-md bg-green-50">
              <Check className="h-5 w-5 text-green-500" />
              <div className="ml-3 text-sm font-medium text-green-800">
                Upload successful! Inventory has been updated.
              </div>
            </div>
          )}
          
          <div className="flex justify-end">
            <button
              type="submit"
              className="px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
              disabled={!file || isUploading}
            >
              {isUploading ? (
                <div className="flex items-center">
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  Uploading...
                </div>
              ) : (
                'Upload and Process'
              )}
            </button>
          </div>
        </div>
      </form>
    </div>
  );
};

export default SalesUploadForm;