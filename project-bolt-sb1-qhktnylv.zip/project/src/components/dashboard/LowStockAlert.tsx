import { useInventory } from '../../context/InventoryContext';
import { Link } from 'react-router-dom';
import { AlertTriangle } from 'lucide-react';

const LowStockAlert = () => {
  const { products, loading } = useInventory();
  
  const lowStockProducts = products.filter(
    product => product.totalStock <= product.reorderLevel
  ).sort((a, b) => a.totalStock - b.totalStock);
  
  if (loading) {
    return (
      <div className="bg-white rounded-lg shadow-sm p-6 animate-pulse">
        <div className="h-6 bg-gray-200 rounded w-1/3 mb-6"></div>
        <div className="space-y-3">
          {[...Array(3)].map((_, index) => (
            <div key={index} className="flex items-center">
              <div className="h-10 w-10 rounded bg-gray-200 mr-3"></div>
              <div className="space-y-2 flex-1">
                <div className="h-4 bg-gray-200 rounded w-1/2"></div>
                <div className="h-3 bg-gray-200 rounded w-1/4"></div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }
  
  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <h3 className="text-lg font-medium text-gray-900 mb-4">Low Stock Items</h3>
      
      {lowStockProducts.length === 0 ? (
        <div className="flex items-center justify-center h-32 bg-gray-50 rounded-lg">
          <div className="text-center">
            <div className="flex justify-center mb-2">
              <div className="bg-green-100 rounded-full p-2">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
              </div>
            </div>
            <p className="text-gray-600 text-sm">All stock levels are healthy</p>
          </div>
        </div>
      ) : (
        <div className="space-y-3 max-h-96 overflow-y-auto pr-1">
          {lowStockProducts.slice(0, 5).map((product) => (
            <div 
              key={product.id} 
              className="flex items-center p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition"
            >
              <div className={`p-2 rounded-md mr-3 ${
                product.totalStock === 0 
                  ? 'bg-red-100 text-red-600' 
                  : 'bg-yellow-100 text-yellow-600'
              }`}>
                <AlertTriangle className="h-5 w-5" />
              </div>
              <div className="flex-1">
                <div className="flex justify-between">
                  <h4 className="text-sm font-medium text-gray-900">{product.name}</h4>
                  <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                    product.totalStock === 0 
                      ? 'bg-red-100 text-red-800' 
                      : 'bg-yellow-100 text-yellow-800'
                  }`}>
                    {product.totalStock === 0 ? 'Out of Stock' : 'Low Stock'}
                  </span>
                </div>
                <div className="flex justify-between mt-1">
                  <p className="text-xs text-gray-500">SKU: {product.sku}</p>
                  <p className="text-xs font-medium text-gray-700">
                    {product.totalStock} / {product.reorderLevel} units
                  </p>
                </div>
              </div>
            </div>
          ))}
          
          {lowStockProducts.length > 5 && (
            <Link 
              to="/dashboard/inventory?filter=lowstock" 
              className="block text-center py-2 text-sm font-medium text-indigo-600 hover:text-indigo-500"
            >
              View all {lowStockProducts.length} low stock items
            </Link>
          )}
        </div>
      )}
    </div>
  );
};

export default LowStockAlert;