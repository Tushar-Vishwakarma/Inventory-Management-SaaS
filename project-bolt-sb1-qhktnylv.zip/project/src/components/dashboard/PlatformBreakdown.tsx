import React, { useMemo } from 'react';
import { useInventory } from '../../context/InventoryContext';

const PlatformBreakdown = () => {
  const { products, loading } = useInventory();
  
  const platformData = useMemo(() => {
    if (!products.length) return [];
    
    const totalAmazon = products.reduce((sum, product) => sum + product.amazonStock, 0);
    const totalFlipkart = products.reduce((sum, product) => sum + product.flipkartStock, 0);
    const totalMeesho = products.reduce((sum, product) => sum + product.meeshoStock, 0);
    const total = totalAmazon + totalFlipkart + totalMeesho;
    
    return [
      {
        name: 'Amazon',
        value: totalAmazon,
        percent: total ? Math.round((totalAmazon / total) * 100) : 0,
        color: 'bg-orange-500'
      },
      {
        name: 'Flipkart',
        value: totalFlipkart,
        percent: total ? Math.round((totalFlipkart / total) * 100) : 0,
        color: 'bg-blue-500'
      },
      {
        name: 'Meesho',
        value: totalMeesho,
        percent: total ? Math.round((totalMeesho / total) * 100) : 0,
        color: 'bg-pink-500'
      }
    ];
  }, [products]);
  
  if (loading) {
    return (
      <div className="bg-white rounded-lg shadow-sm p-6 animate-pulse">
        <div className="h-6 bg-gray-200 rounded w-1/4 mb-6"></div>
        {[...Array(3)].map((_, index) => (
          <div key={index} className="mb-4">
            <div className="h-4 bg-gray-200 rounded w-1/5 mb-2"></div>
            <div className="h-4 bg-gray-200 rounded w-full"></div>
          </div>
        ))}
      </div>
    );
  }
  
  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <h3 className="text-lg font-medium text-gray-900 mb-4">Platform Breakdown</h3>
      
      <div className="space-y-4">
        {platformData.map((platform) => (
          <div key={platform.name}>
            <div className="flex justify-between items-center mb-1">
              <div className="flex items-center">
                <div className={`h-3 w-3 rounded-full ${platform.color} mr-2`}></div>
                <span className="text-sm font-medium text-gray-700">{platform.name}</span>
              </div>
              <div className="text-sm text-gray-500">
                {platform.value} units <span className="font-medium">({platform.percent}%)</span>
              </div>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2.5">
              <div 
                className={`h-2.5 rounded-full ${platform.color}`} 
                style={{ width: `${platform.percent}%` }}
              ></div>
            </div>
          </div>
        ))}
      </div>
      
      <div className="mt-6">
        <h4 className="text-sm font-medium text-gray-500 mb-2">Total Distribution</h4>
        <div className="flex h-4 rounded-lg overflow-hidden">
          {platformData.map((platform) => (
            <div 
              key={platform.name}
              className={`${platform.color}`} 
              style={{ width: `${platform.percent}%` }}
            ></div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default PlatformBreakdown;