import { 
  PackageOpen, 
  ShoppingCart, 
  AlertTriangle, 
  TrendingUp, 
  TrendingDown 
} from 'lucide-react';
import { useInventory } from '../../context/InventoryContext';

const StatsCards = () => {
  const { products, loading } = useInventory();
  
  const totalProducts = products.length;
  const totalStock = products.reduce((sum, product) => sum + product.totalStock, 0);
  const lowStockCount = products.filter(p => p.totalStock <= p.reorderLevel).length;
  const outOfStockCount = products.filter(p => p.totalStock === 0).length;
  
  // Placeholder stats (to be replaced with real data in a full implementation)
  const salesTrend = 5.2; // percent increase
  
  if (loading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {[...Array(4)].map((_, index) => (
          <div key={index} className="bg-white p-6 rounded-lg shadow-sm animate-pulse">
            <div className="h-8 bg-gray-200 rounded w-1/3 mb-4"></div>
            <div className="h-10 bg-gray-200 rounded w-1/2 mb-2"></div>
            <div className="h-4 bg-gray-200 rounded w-2/3"></div>
          </div>
        ))}
      </div>
    );
  }
  
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
      {/* Total products */}
      <div className="bg-white p-6 rounded-lg shadow-sm">
        <div className="flex items-center">
          <div className="flex-shrink-0">
            <PackageOpen className="h-8 w-8 text-indigo-600" />
          </div>
          <div className="ml-5 w-0 flex-1">
            <dl>
              <dt className="text-sm font-medium text-gray-500 truncate">Total Products</dt>
              <dd>
                <div className="text-lg font-semibold text-gray-900">{totalProducts}</div>
              </dd>
            </dl>
          </div>
        </div>
        <div className="mt-4">
          <div className="flex items-center text-sm text-gray-500">
            <span>Across all platforms</span>
          </div>
        </div>
      </div>
      
      {/* Total stock */}
      <div className="bg-white p-6 rounded-lg shadow-sm">
        <div className="flex items-center">
          <div className="flex-shrink-0">
            <ShoppingCart className="h-8 w-8 text-blue-600" />
          </div>
          <div className="ml-5 w-0 flex-1">
            <dl>
              <dt className="text-sm font-medium text-gray-500 truncate">Total Stock</dt>
              <dd>
                <div className="text-lg font-semibold text-gray-900">{totalStock}</div>
              </dd>
            </dl>
          </div>
        </div>
        <div className="mt-4">
          <div className="flex items-center text-sm text-gray-500">
            <span>Units in stock</span>
          </div>
        </div>
      </div>
      
      {/* Low stock */}
      <div className="bg-white p-6 rounded-lg shadow-sm">
        <div className="flex items-center">
          <div className="flex-shrink-0">
            <AlertTriangle className="h-8 w-8 text-yellow-500" />
          </div>
          <div className="ml-5 w-0 flex-1">
            <dl>
              <dt className="text-sm font-medium text-gray-500 truncate">Low Stock Items</dt>
              <dd>
                <div className="text-lg font-semibold text-gray-900">{lowStockCount}</div>
              </dd>
            </dl>
          </div>
        </div>
        <div className="mt-4">
          <div className="flex items-center text-sm text-yellow-600">
            <span>Needs attention</span>
            {outOfStockCount > 0 && (
              <span className="ml-2 px-2 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
                {outOfStockCount} out of stock
              </span>
            )}
          </div>
        </div>
      </div>
      
      {/* Sales trend */}
      <div className="bg-white p-6 rounded-lg shadow-sm">
        <div className="flex items-center">
          <div className="flex-shrink-0">
            {salesTrend >= 0 ? (
              <TrendingUp className="h-8 w-8 text-green-500" />
            ) : (
              <TrendingDown className="h-8 w-8 text-red-500" />
            )}
          </div>
          <div className="ml-5 w-0 flex-1">
            <dl>
              <dt className="text-sm font-medium text-gray-500 truncate">Weekly Sales</dt>
              <dd>
                <div className="text-lg font-semibold text-gray-900">
                  {salesTrend >= 0 ? '+' : ''}{salesTrend}%
                </div>
              </dd>
            </dl>
          </div>
        </div>
        <div className="mt-4">
          <div className={`flex items-center text-sm ${
            salesTrend >= 0 ? 'text-green-600' : 'text-red-600'
          }`}>
            <span>
              {salesTrend >= 0 ? 'Increasing' : 'Decreasing'} from last week
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StatsCards;