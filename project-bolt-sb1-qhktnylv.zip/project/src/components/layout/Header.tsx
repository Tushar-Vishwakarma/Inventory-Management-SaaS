import { useState } from 'react';
import { Menu, Bell, User } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

interface HeaderProps {
  sidebarOpen: boolean;
  setSidebarOpen: (open: boolean) => void;
  user: any;
}

const Header = ({ sidebarOpen, setSidebarOpen, user }: HeaderProps) => {
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const { logout } = useAuth();

  const handleLogout = () => {
    logout();
    setUserMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-30 bg-white border-b border-gray-200">
      <div className="px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 -mb-px">
          {/* Header: Left side */}
          <div className="flex">
            {/* Hamburger button */}
            <button
              className="text-gray-500 hover:text-gray-600 lg:hidden"
              aria-controls="sidebar"
              aria-expanded={sidebarOpen}
              onClick={() => setSidebarOpen(!sidebarOpen)}
            >
              <span className="sr-only">Open sidebar</span>
              <Menu className="w-6 h-6" />
            </button>
          </div>

          {/* Header: Right side */}
          <div className="flex items-center space-x-3">
            {/* Notifications */}
            <div className="relative">
              <button
                className="flex items-center justify-center p-2 rounded-full bg-gray-100 hover:bg-gray-200"
                aria-haspopup="true"
                onClick={() => setNotificationsOpen(!notificationsOpen)}
                aria-expanded={notificationsOpen}
              >
                <span className="sr-only">Notifications</span>
                <Bell className="w-5 h-5" />
                <div className="absolute top-0 right-0 w-2 h-2 bg-red-500 rounded-full"></div>
              </button>
              {notificationsOpen && (
                <div 
                  className="absolute top-full right-0 w-80 mt-2 bg-white border border-gray-200 rounded-lg shadow-lg py-2"
                  onClick={() => setNotificationsOpen(false)}
                >
                  <div className="px-4 py-2 border-b border-gray-100">
                    <p className="font-semibold text-gray-800">Notifications</p>
                  </div>
                  <div className="p-3">
                    <div className="flex items-start p-2 bg-blue-50 rounded-lg mb-2">
                      <div className="ml-2">
                        <p className="text-sm text-blue-800 font-medium">Low stock alert</p>
                        <p className="text-xs text-blue-600">TSH001 - Black Tee M is below reorder level</p>
                      </div>
                    </div>
                    <div className="flex items-start p-2">
                      <div className="ml-2">
                        <p className="text-sm text-gray-800 font-medium">Inventory updated</p>
                        <p className="text-xs text-gray-500">5 products updated on Apr 15, 2025</p>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
            
            {/* User menu */}
            <div className="relative inline-flex">
              <button
                className="inline-flex items-center justify-center p-2 rounded-full bg-gray-100 hover:bg-gray-200"
                aria-haspopup="true"
                onClick={() => setUserMenuOpen(!userMenuOpen)}
                aria-expanded={userMenuOpen}
              >
                <span className="sr-only">User menu</span>
                <User className="w-5 h-5" />
              </button>
              
              {userMenuOpen && (
                <div className="absolute top-full right-0 w-48 mt-2 bg-white border border-gray-200 rounded-lg shadow-lg py-2">
                  <div className="px-4 py-2 border-b border-gray-100">
                    <p className="font-semibold text-gray-800">{user?.email || 'User'}</p>
                  </div>
                  <button
                    className="w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                    onClick={() => {}}
                  >
                    Account Settings
                  </button>
                  <button
                    className="w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                    onClick={handleLogout}
                  >
                    Sign Out
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;