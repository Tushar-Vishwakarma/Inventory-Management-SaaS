import { NavLink } from 'react-router-dom';
import { 
  X, 
  LayoutDashboard, 
  Package, 
  ShoppingCart, 
  BarChart3, 
  Settings,
  Database 
} from 'lucide-react';

interface SidebarProps {
  sidebarOpen: boolean;
  setSidebarOpen: (open: boolean) => void;
}

const Sidebar = ({ sidebarOpen, setSidebarOpen }: SidebarProps) => {
  return (
    <div>
      {/* Sidebar backdrop (mobile only) */}
      <div
        className={`fixed inset-0 bg-gray-900 bg-opacity-30 z-40 lg:hidden lg:z-auto transition-opacity duration-200 ${
          sidebarOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'
        }`}
        aria-hidden="true"
        onClick={() => setSidebarOpen(false)}
      ></div>

      {/* Sidebar */}
      <div
        className={`flex flex-col absolute z-40 left-0 top-0 lg:static lg:left-auto lg:top-auto lg:translate-x-0 h-screen overflow-y-scroll lg:overflow-y-auto no-scrollbar w-64 lg:w-72 lg:sidebar bg-indigo-700 p-4 transition-all duration-200 ease-in-out ${
          sidebarOpen ? 'translate-x-0' : '-translate-x-64'
        }`}
      >
        {/* Sidebar header */}
        <div className="flex justify-between items-center mb-10 pr-3 sm:px-2">
          {/* Logo */}
          <NavLink to="/" className="flex items-center">
            <Database className="w-8 h-8 text-indigo-200" />
            <span className="ml-3 text-xl font-bold text-white">InventorySync</span>
          </NavLink>
          {/* Close button */}
          <button
            className="lg:hidden text-indigo-200 hover:text-white"
            onClick={() => setSidebarOpen(!sidebarOpen)}
          >
            <span className="sr-only">Close sidebar</span>
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Navigation */}
        <nav className="space-y-1">
          <NavLink
            to="/dashboard"
            end
            className={({ isActive }) =>
              `flex items-center px-4 py-3 rounded-lg ${
                isActive
                  ? 'bg-indigo-900 text-white'
                  : 'text-indigo-200 hover:text-white hover:bg-indigo-800'
              }`
            }
          >
            <LayoutDashboard className="w-5 h-5 mr-3" />
            <span>Dashboard</span>
          </NavLink>

          <NavLink
            to="/dashboard/inventory"
            className={({ isActive }) =>
              `flex items-center px-4 py-3 rounded-lg ${
                isActive
                  ? 'bg-indigo-900 text-white'
                  : 'text-indigo-200 hover:text-white hover:bg-indigo-800'
              }`
            }
          >
            <Package className="w-5 h-5 mr-3" />
            <span>Inventory</span>
          </NavLink>

          <NavLink
            to="/dashboard/sales"
            className={({ isActive }) =>
              `flex items-center px-4 py-3 rounded-lg ${
                isActive
                  ? 'bg-indigo-900 text-white'
                  : 'text-indigo-200 hover:text-white hover:bg-indigo-800'
              }`
            }
          >
            <ShoppingCart className="w-5 h-5 mr-3" />
            <span>Sales</span>
          </NavLink>

          <NavLink
            to="/dashboard/reports"
            className={({ isActive }) =>
              `flex items-center px-4 py-3 rounded-lg ${
                isActive
                  ? 'bg-indigo-900 text-white'
                  : 'text-indigo-200 hover:text-white hover:bg-indigo-800'
              }`
            }
          >
            <BarChart3 className="w-5 h-5 mr-3" />
            <span>Reports</span>
          </NavLink>

          <NavLink
            to="/dashboard/settings"
            className={({ isActive }) =>
              `flex items-center px-4 py-3 rounded-lg ${
                isActive
                  ? 'bg-indigo-900 text-white'
                  : 'text-indigo-200 hover:text-white hover:bg-indigo-800'
              }`
            }
          >
            <Settings className="w-5 h-5 mr-3" />
            <span>Settings</span>
          </NavLink>
        </nav>

        <div className="mt-auto pt-3">
          <div className="px-4 py-3 rounded-lg bg-indigo-800 text-indigo-100 mb-2">
            <div className="text-xs font-medium uppercase">Free Trial</div>
            <div className="text-sm">15 days remaining</div>
            <div className="mt-2">
              <div className="bg-indigo-900 rounded-full h-2 overflow-hidden">
                <div className="bg-indigo-400 h-2 w-1/2"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;