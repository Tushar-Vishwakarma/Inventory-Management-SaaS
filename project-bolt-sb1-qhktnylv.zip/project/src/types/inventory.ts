export interface Product {
  id: string;
  sku: string;
  name: string;
  amazonStock: number;
  flipkartStock: number;
  meeshoStock: number;
  totalStock: number;
  reorderLevel: number;
}

export interface SaleRecord {
  date: string;
  sku: string;
  platform: string;
  quantity: number;
}