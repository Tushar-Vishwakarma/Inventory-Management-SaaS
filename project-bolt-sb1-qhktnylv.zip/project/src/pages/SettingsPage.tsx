const SettingsPage = () => {
  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Settings</h1>
        <p className="text-gray-500">Manage your account and preferences</p>
      </div>
      
      <div className="bg-white rounded-lg shadow-sm overflow-hidden">
        <div className="p-6 border-b border-gray-200">
          <h3 className="text-lg font-medium text-gray-900">Google Sheets Integration</h3>
          <p className="mt-1 text-sm text-gray-500">
            Configure your Google Sheets connection for inventory management
          </p>
        </div>
        
        <div className="px-6 py-4">
          <div className="flex items-center justify-between bg-green-50 p-4 rounded-md">
            <div>
              <h4 className="text-sm font-medium text-green-800">Connected to Google Sheets</h4>
              <p className="text-xs text-green-700 mt-1">
                Your inventory sheet is connected and synchronized
              </p>
            </div>
            <div className="ml-4">
              <button
                type="button"
                className="inline-flex items-center px-2.5 py-1.5 border border-transparent text-xs font-medium rounded text-green-700 bg-green-100 hover:bg-green-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
              >
                Reconnect
              </button>
            </div>
          </div>
          
          <div className="mt-6">
            <h4 className="text-sm font-medium text-gray-900 mb-4">Sheet Configuration</h4>
            
            <div className="space-y-4">
              <div>
                <label htmlFor="sheet-id" className="block text-sm font-medium text-gray-700">
                  Sheet ID
                </label>
                <div className="mt-1 flex rounded-md shadow-sm">
                  <input
                    type="text"
                    name="sheet-id"
                    id="sheet-id"
                    className="flex-1 min-w-0 block w-full px-3 py-2 rounded-md border border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                    value="1xYzAbC_dEfGhIjKlMnOpQrStUvWxYz12345678"
                    disabled
                  />
                </div>
                <p className="mt-1 text-xs text-gray-500">
                  This is your Google Sheet identifier
                </p>
              </div>
              
              <div>
                <label htmlFor="inventory-tab" className="block text-sm font-medium text-gray-700">
                  Inventory Tab Name
                </label>
                <div className="mt-1">
                  <input
                    type="text"
                    name="inventory-tab"
                    id="inventory-tab"
                    className="shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md"
                    defaultValue="Inventory"
                  />
                </div>
              </div>
              
              <div>
                <label htmlFor="sales-tab" className="block text-sm font-medium text-gray-700">
                  Sales Upload Tab Name
                </label>
                <div className="mt-1">
                  <input
                    type="text"
                    name="sales-tab"
                    id="sales-tab"
                    className="shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md"
                    defaultValue="Sales Upload"
                  />
                </div>
              </div>
            </div>
          </div>
          
          <div className="mt-6">
            <h4 className="text-sm font-medium text-gray-900 mb-4">Sync Settings</h4>
            
            <div className="space-y-4">
              <div className="flex items-start">
                <div className="flex items-center h-5">
                  <input
                    id="auto-sync"
                    name="auto-sync"
                    type="checkbox"
                    className="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300 rounded"
                    defaultChecked
                  />
                </div>
                <div className="ml-3 text-sm">
                  <label htmlFor="auto-sync" className="font-medium text-gray-700">
                    Auto-sync
                  </label>
                  <p className="text-gray-500">Automatically sync inventory every 30 minutes</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="flex items-center h-5">
                  <input
                    id="email-alerts"
                    name="email-alerts"
                    type="checkbox"
                    className="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300 rounded"
                    defaultChecked
                  />
                </div>
                <div className="ml-3 text-sm">
                  <label htmlFor="email-alerts" className="font-medium text-gray-700">
                    Email Alerts
                  </label>
                  <p className="text-gray-500">Receive email notifications for low stock items</p>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <div className="px-6 py-4 bg-gray-50 flex justify-end">
          <button
            type="button"
            className="px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
          >
            Cancel
          </button>
          <button
            type="button"
            className="ml-3 px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
          >
            Save Settings
          </button>
        </div>
      </div>
    </div>
  );
};

export default SettingsPage;