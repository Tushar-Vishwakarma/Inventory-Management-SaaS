const ReportsPage = () => {
  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Reports</h1>
        <p className="text-gray-500">View insights and analytics</p>
      </div>
      
      <div className="bg-white rounded-lg shadow-sm p-6">
        <div className="text-center py-16">
          <h3 className="text-lg font-medium text-gray-500 mb-2">Coming Soon</h3>
          <p className="text-gray-400">
            Advanced analytics and reporting features will be available in future updates.
          </p>
        </div>
      </div>
    </div>
  );
};

export default ReportsPage;