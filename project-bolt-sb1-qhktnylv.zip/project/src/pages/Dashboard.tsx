import { Routes, Route } from 'react-router-dom';
import InventoryPage from './InventoryPage';
import SalesPage from './SalesPage';
import ReportsPage from './ReportsPage';
import SettingsPage from './SettingsPage';
import DashboardHome from './DashboardHome';

const Dashboard = () => {
  return (
    <Routes>
      <Route path="/" element={<DashboardHome />} />
      <Route path="/inventory" element={<InventoryPage />} />
      <Route path="/sales" element={<SalesPage />} />
      <Route path="/reports" element={<ReportsPage />} />
      <Route path="/settings" element={<SettingsPage />} />
    </Routes>
  );
};

export default Dashboard;