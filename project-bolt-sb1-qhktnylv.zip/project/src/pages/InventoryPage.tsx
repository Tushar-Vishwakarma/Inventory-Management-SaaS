import { Link } from 'react-router-dom';
import { useState } from 'react';
import { Plus } from 'lucide-react';
import InventoryTable from '../components/inventory/InventoryTable';
import InventoryEditModal from '../components/inventory/InventoryEditModal';
import { Product } from '../types/inventory';

const InventoryPage = () => {
  const [showAddModal, setShowAddModal] = useState(false);
  
  const emptyProduct: Product = {
    id: '',
    sku: '',
    name: '',
    amazonStock: 0,
    flipkartStock: 0,
    meeshoStock: 0,
    totalStock: 0,
    reorderLevel: 5
  };
  
  return (
    <div>
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Inventory</h1>
          <p className="text-gray-500">Manage your products and stock levels</p>
        </div>
        
        <div className="mt-4 sm:mt-0">
          <button
            className="flex items-center justify-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
            onClick={() => setShowAddModal(true)}
          >
            <Plus className="h-4 w-4 mr-2" />
            Add Product
          </button>
        </div>
      </div>
      
      <InventoryTable />
      
      {showAddModal && (
        <InventoryEditModal
          product={emptyProduct}
          isOpen={showAddModal}
          onClose={() => setShowAddModal(false)}
        />
      )}
    </div>
  );
};

export default InventoryPage;