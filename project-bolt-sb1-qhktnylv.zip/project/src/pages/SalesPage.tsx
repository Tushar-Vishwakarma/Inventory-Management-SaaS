import SalesUploadForm from '../components/sales/SalesUploadForm';

const SalesPage = () => {
  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Sales</h1>
        <p className="text-gray-500">Upload and manage your sales data</p>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <SalesUploadForm />
        </div>
        <div>
          <div className="bg-white rounded-lg shadow-sm overflow-hidden">
            <div className="p-6">
              <h3 className="text-lg font-medium text-gray-900 mb-4">CSV Template</h3>
              <p className="text-gray-500 text-sm mb-4">
                Download a template for uploading your sales data. The CSV file must include the following columns:
              </p>
              
              <div className="bg-gray-50 p-4 rounded-md mb-4">
                <table className="min-w-full text-sm">
                  <thead>
                    <tr>
                      <th className="text-left font-medium text-gray-700 pb-2">date</th>
                      <th className="text-left font-medium text-gray-700 pb-2">sku</th>
                      <th className="text-left font-medium text-gray-700 pb-2">platform</th>
                      <th className="text-left font-medium text-gray-700 pb-2">quantity</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td className="text-gray-600 pt-1">2025-04-16</td>
                      <td className="text-gray-600 pt-1">TSH001</td>
                      <td className="text-gray-600 pt-1">amazon</td>
                      <td className="text-gray-600 pt-1">2</td>
                    </tr>
                  </tbody>
                </table>
              </div>
              
              <div className="flex justify-center">
                <button
                  className="px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                >
                  Download Template
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SalesPage;