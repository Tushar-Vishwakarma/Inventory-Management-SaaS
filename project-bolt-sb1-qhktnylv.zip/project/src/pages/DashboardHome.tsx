import { useAuth } from '../context/AuthContext';
import StatsCards from '../components/dashboard/StatsCards';
import LowStockAlert from '../components/dashboard/LowStockAlert';
import PlatformBreakdown from '../components/dashboard/PlatformBreakdown';

const DashboardHome = () => {
  const { user } = useAuth();
  
  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
        <p className="text-gray-500">Welcome back, {user?.email || 'User'}</p>
      </div>
      
      <StatsCards />
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-6">
        <div className="lg:col-span-2">
          <LowStockAlert />
        </div>
        <div>
          <PlatformBreakdown />
        </div>
      </div>
    </div>
  );
};

export default DashboardHome;