export const SHEET_CONFIG = {
  // Replace with your Google Sheet ID when setting up
  SHEET_ID: '1xYzAbC_dEfGhIjKlMnOpQrStUvWxYz12345678',
  
  // Sheet names
  SHEETS: {
    INVENTORY: 'Inventory',
    SALES: 'Sales Upload'
  },
  
  // Column mappings for Inventory sheet
  INVENTORY_COLUMNS: {
    SKU: 'A',
    PRODUCT_NAME: 'B',
    AMAZON_STOCK: 'C',
    FLIPKART_STOCK: 'D',
    MEESHO_STOCK: 'E',
    TOTAL_STOCK: 'F',
    REORDER_LEVEL: 'G'
  },
  
  // Column mappings for Sales Upload sheet
  SALES_COLUMNS: {
    DATE: 'A',
    SKU: 'B',
    PLATFORM: 'C',
    QUANTITY: 'D'
  }
};

// Google Sheet structure:
// https://docs.google.com/spreadsheets/d/1xYzAbC_dEfGhIjKlMnOpQrStUvWxYz12345678/edit

/*
Sheet 1: "Inventory"
| SKU    | Product Name  | Amazon Stock | Flipkart Stock | Meesho Stock | Total Stock | Reorder Level |
|--------|---------------|--------------|----------------|--------------|-------------|---------------|
| TSH001 | Black Tee M  | 5           | 3              | 2            | 10          | 5             |
| TSH002 | White Tee L  | 8           | 4              | 3            | 15          | 8             |
| JNS001 | Blue Jeans 32| 2           | 1              | 0            | 3           | 6             |

Sheet 2: "Sales Upload"
| Date       | SKU    | Platform | Quantity |
|------------|--------|----------|----------|
| 2025-04-16 | TSH001 | amazon   | 2        |
| 2025-04-16 | TSH002 | flipkart | 1        |
*/