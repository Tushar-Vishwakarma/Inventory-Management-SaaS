import { Product, SaleRecord } from '../types/inventory';

// Mock data for inventory
const mockProducts: Product[] = [
  {
    id: '1',
    sku: 'TSH001',
    name: 'Black Tee M',
    amazonStock: 5,
    flipkartStock: 3,
    meeshoStock: 2,
    totalStock: 10,
    reorderLevel: 5
  },
  {
    id: '2',
    sku: 'TSH002',
    name: 'White Tee L',
    amazonStock: 8,
    flipkartStock: 4,
    meeshoStock: 3,
    totalStock: 15,
    reorderLevel: 8
  },
  {
    id: '3',
    sku: 'JNS001',
    name: 'Blue Jeans 32',
    amazonStock: 2,
    flipkartStock: 1,
    meeshoStock: 0,
    totalStock: 3,
    reorderLevel: 6
  },
  {
    id: '4',
    sku: 'SHR001',
    name: 'Formal Shirt M',
    amazonStock: 0,
    flipkartStock: 1,
    meeshoStock: 1,
    totalStock: 2,
    reorderLevel: 4
  },
  {
    id: '5',
    sku: 'SHO001',
    name: 'Running Shoes 42',
    amazonStock: 12,
    flipkartStock: 8,
    meeshoStock: 5,
    totalStock: 25,
    reorderLevel: 10
  }
];

// Function to fetch inventory data from Google Sheets
export const getInventory = async (): Promise<Product[]> => {
  // In a real implementation, this would call the Google Sheets API
  // For this demo, we'll return mock data with a simulated delay
  return new Promise(resolve => {
    setTimeout(() => {
      resolve([...mockProducts]);
    }, 1000);
  });
};

// Function to update an inventory item in Google Sheets
export const updateInventoryItem = async (product: Product): Promise<void> => {
  // In a real implementation, this would call the Google Sheets API
  // For this demo, we'll update the mock data with a simulated delay
  return new Promise(resolve => {
    setTimeout(() => {
      const index = mockProducts.findIndex(p => p.id === product.id);
      
      if (index !== -1) {
        mockProducts[index] = product;
      } else {
        // New product
        const newProduct = {
          ...product,
          id: Date.now().toString() // Generate a simple ID
        };
        mockProducts.push(newProduct);
      }
      
      resolve();
    }, 1000);
  });
};

// Function to delete an inventory item from Google Sheets
export const deleteInventoryItem = async (id: string): Promise<void> => {
  // In a real implementation, this would call the Google Sheets API
  // For this demo, we'll update the mock data with a simulated delay
  return new Promise(resolve => {
    setTimeout(() => {
      const index = mockProducts.findIndex(p => p.id === id);
      
      if (index !== -1) {
        mockProducts.splice(index, 1);
      }
      
      resolve();
    }, 1000);
  });
};

// Function to process sales data and update inventory
export const processSalesData = async (csvData: string): Promise<{ updatedCount: number }> => {
  // In a real implementation, this would parse the CSV and update the Google Sheet
  // For this demo, we'll simulate processing with a delay
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      try {
        // Parse CSV
        const lines = csvData.split('\n');
        const headers = lines[0].split(',');
        
        // Check for required headers
        const requiredHeaders = ['date', 'sku', 'platform', 'quantity'];
        const missingHeaders = requiredHeaders.filter(
          (header) => !headers.map(h => h.trim().toLowerCase()).includes(header)
        );
        
        if (missingHeaders.length > 0) {
          reject(new Error(`Missing required headers: ${missingHeaders.join(', ')}`));
          return;
        }
        
        const salesRecords: SaleRecord[] = [];
        
        // Parse data rows
        for (let i = 1; i < lines.length; i++) {
          if (lines[i].trim() === '') continue;
          
          const values = lines[i].split(',');
          const record: SaleRecord = {
            date: values[headers.indexOf('date')].trim(),
            sku: values[headers.indexOf('sku')].trim(),
            platform: values[headers.indexOf('platform')].trim().toLowerCase(),
            quantity: parseInt(values[headers.indexOf('quantity')].trim(), 10) || 0
          };
          
          salesRecords.push(record);
        }
        
        // Update inventory based on sales records
        let updatedCount = 0;
        
        for (const record of salesRecords) {
          const product = mockProducts.find(p => p.sku === record.sku);
          
          if (product) {
            // Update stock based on platform
            if (record.platform === 'amazon' && product.amazonStock >= record.quantity) {
              product.amazonStock -= record.quantity;
              product.totalStock -= record.quantity;
              updatedCount++;
            } else if (record.platform === 'flipkart' && product.flipkartStock >= record.quantity) {
              product.flipkartStock -= record.quantity;
              product.totalStock -= record.quantity;
              updatedCount++;
            } else if (record.platform === 'meesho' && product.meeshoStock >= record.quantity) {
              product.meeshoStock -= record.quantity;
              product.totalStock -= record.quantity;
              updatedCount++;
            }
          }
        }
        
        resolve({ updatedCount });
      } catch (error) {
        reject(error);
      }
    }, 1500);
  });
};