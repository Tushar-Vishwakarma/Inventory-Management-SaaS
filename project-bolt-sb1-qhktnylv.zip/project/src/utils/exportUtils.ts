import { Product } from '../types/inventory';

export const downloadCSV = (data: Product[], filename: string) => {
  // Convert the products to CSV format
  const headers = ['SKU', 'Product Name', 'Amazon Stock', 'Flipkart Stock', 'Meesho Stock', 'Total Stock', 'Reorder Level'];
  
  const csvContent = [
    headers.join(','),
    ...data.map(product => [
      product.sku,
      product.name.replace(/,/g, ' '), // Escape commas in product names
      product.amazonStock,
      product.flipkartStock,
      product.meeshoStock,
      product.totalStock,
      product.reorderLevel
    ].join(','))
  ].join('\n');
  
  // Create a blob and download
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', `${filename}_${new Date().toISOString().split('T')[0]}.csv`);
  link.style.visibility = 'hidden';
  
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};

export const formatCsvTemplate = () => {
  const headers = ['date', 'sku', 'platform', 'quantity'];
  const sampleRow = ['2025-04-16', 'TSH001', 'amazon', '2'];
  
  return [headers.join(','), sampleRow.join(',')].join('\n');
};